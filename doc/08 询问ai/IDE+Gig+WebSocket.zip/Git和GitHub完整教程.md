# Git 和 GitHub 完整教程 - 从零开始

> **目标读者**: 完全不懂Git的开发者  
> **学习时间**: 1-2小时  
> **实践项目**: OKX-MT5套利交易系统

---

## 📚 目录

1. [什么是Git和GitHub](#什么是git和github)
2. [安装Git](#安装git)
3. [Git基础概念](#git基础概念)
4. [Git基本操作](#git基本操作)
5. [GitHub使用](#github使用)
6. [实战：管理您的项目](#实战管理您的项目)
7. [AI协作最佳实践](#ai协作最佳实践)
8. [常见问题](#常见问题)

---

## 1. 什么是Git和GitHub {#什么是git和github}

### Git 是什么？

**简单理解**：Git就像是一个"时光机"，可以：
- 📸 给代码拍"快照"（保存每个版本）
- ⏪ 随时回到过去的任何版本
- 🌿 同时开发多个功能（分支）
- 🔄 合并不同的修改

**为什么需要Git？**

没有Git的情况：
```
我的项目/
├── 项目_最终版.zip
├── 项目_最终版2.zip
├── 项目_真的最终版.zip
├── 项目_这次真的是最终版.zip
└── 项目_老板让改的版本.zip
```

有Git的情况：
```
我的项目/
└── .git/  （自动管理所有版本）

# 可以随时查看任何历史版本
git log
commit a1b2c3d "完成WebSocket"
commit d4e5f6g "完成REST API"
commit g7h8i9j "初始版本"
```

### GitHub 是什么？

**简单理解**：GitHub就像是"代码的云盘"，可以：
- ☁️ 把代码备份到云端
- 👥 与他人协作（包括AI）
- 📊 管理项目进度
- 🐛 追踪Bug

**Git vs GitHub**：
- **Git**: 本地工具（在你电脑上）
- **GitHub**: 网站（在互联网上）
- **关系**: Git管理代码，GitHub存储代码

---

## 2. 安装Git {#安装git}

### Windows安装（推荐）

#### 方法1：使用MSYS2（您已经有了）

```bash
# 打开MSYS2终端
pacman -S git

# 验证安装
git --version
# 输出：git version 2.42.0
```

#### 方法2：官方安装包

1. 访问：https://git-scm.com/download/win
2. 下载Windows版本
3. 安装时**全部选默认选项**
4. 打开cmd或PowerShell验证：
   ```bash
   git --version
   ```

### 首次配置（重要）

安装后必须配置用户信息：

```bash
# 设置用户名（随便起，建议用真名或昵称）
git config --global user.name "您的名字"

# 设置邮箱（建议用GitHub注册邮箱）
git config --global user.email "your.email@example.com"

# 设置默认编辑器（可选，推荐VS Code）
git config --global core.editor "code --wait"

# 设置默认分支名为main（新标准）
git config --global init.defaultBranch main

# 查看配置
git config --list
```

---

## 3. Git基础概念 {#git基础概念}

### 3.1 工作区、暂存区、仓库

理解这三个区域是学习Git的关键：

```
┌─────────────────────────────────────────────────┐
│  工作区 (Working Directory)                      │
│  - 你实际编辑代码的地方                          │
│  - 就是项目文件夹                                │
│                                                  │
│  你修改了文件 →                                  │
│         ↓                                        │
│  ┌───────────────────────────────────────────┐  │
│  │  暂存区 (Staging Area / Index)            │  │
│  │  - 准备提交的文件                          │  │
│  │  - 像是"购物车"                            │  │
│  │                                            │  │
│  │  git add 文件 →                            │  │
│  │         ↓                                  │  │
│  │  ┌──────────────────────────────────────┐ │  │
│  │  │  仓库 (Repository / .git)            │ │  │
│  │  │  - 保存的版本历史                     │ │  │
│  │  │  - 像是"永久存档"                     │ │  │
│  │  │                                       │ │  │
│  │  │  git commit →                         │ │  │
│  │  │         ↓                             │ │  │
│  │  │  [版本历史记录]                       │ │  │
│  │  └──────────────────────────────────────┘ │  │
│  └───────────────────────────────────────────┘  │
└─────────────────────────────────────────────────┘
```

**类比理解**：
- **工作区** = 你的书桌（正在写作业）
- **暂存区** = 你整理好的作业（准备交）
- **仓库** = 老师的档案柜（保存的作业）

### 3.2 文件状态

文件在Git中有4种状态：

```
Untracked (未跟踪)
   ↓ git add
Staged (已暂存)
   ↓ git commit
Committed (已提交)
   ↓ 修改文件
Modified (已修改)
   ↓ git add
Staged (已暂存)
   ↓ git commit
Committed (已提交)
```

### 3.3 分支（Branch）

**什么是分支？**

想象一本小说：
- **主线剧情** = main分支（主分支）
- **平行宇宙** = 其他分支（功能分支）

```
main分支:     A---B---C---D---E
                   \       /
feature分支:         F---G
```

**为什么需要分支？**
- ✅ 开发新功能不影响主线
- ✅ 多个功能同时开发
- ✅ 实验失败可以直接删除分支

---

## 4. Git基本操作 {#git基本操作}

### 4.1 创建仓库

#### 场景1：从零开始

```bash
# 1. 创建项目文件夹
mkdir my-project
cd my-project

# 2. 初始化Git仓库
git init

# 输出：Initialized empty Git repository in /path/to/my-project/.git/

# 3. 查看状态
git status
# 输出：On branch main
#      No commits yet
```

#### 场景2：已有项目（您的情况）

```bash
# 进入项目目录
cd /path/to/OKX-MT5-Arbitrage

# 初始化Git
git init

# 查看现有文件
git status
# 会显示所有文件都是Untracked（未跟踪）
```

### 4.2 基本工作流程

这是您每天都会用到的流程：

```bash
# ==================== 步骤1：查看状态 ====================
git status
# 输出：
# On branch main
# Changes not staged for commit:
#   modified:   src/okx_websocket.cpp
# Untracked files:
#   tests/test_websocket.cpp

# ==================== 步骤2：添加文件到暂存区 ====================
# 添加单个文件
git add src/okx_websocket.cpp

# 添加多个文件
git add tests/test_websocket.cpp docs/websocket_guide.md

# 添加整个目录
git add src/

# 添加所有修改（最常用）
git add .

# ==================== 步骤3：查看暂存区 ====================
git status
# 输出：
# On branch main
# Changes to be committed:
#   modified:   src/okx_websocket.cpp
#   new file:   tests/test_websocket.cpp

# ==================== 步骤4：提交到仓库 ====================
git commit -m "完成WebSocket基础实现"

# 输出：
# [main a1b2c3d] 完成WebSocket基础实现
#  2 files changed, 2500 insertions(+)

# ==================== 步骤5：查看历史 ====================
git log
# 输出：
# commit a1b2c3d4e5f6g7h8i9j0 (HEAD -> main)
# Author: Your Name <your.email@example.com>
# Date:   Tue Nov 5 15:30:00 2025
#
#     完成WebSocket基础实现

# 简洁查看
git log --oneline
# 输出：
# a1b2c3d 完成WebSocket基础实现
# d4e5f6g 完成REST API
# g7h8i9j 初始提交
```

### 4.3 分支操作

```bash
# ==================== 查看分支 ====================
git branch
# * main  （*表示当前分支）

# ==================== 创建新分支 ====================
git branch feature/websocket

# 查看所有分支
git branch
# * main
#   feature/websocket

# ==================== 切换分支 ====================
git checkout feature/websocket
# 或使用新命令
git switch feature/websocket

# 输出：Switched to branch 'feature/websocket'

# ==================== 创建并切换（常用） ====================
git checkout -b feature/cache
# 等同于：
# git branch feature/cache
# git checkout feature/cache

# ==================== 查看当前分支 ====================
git branch
#   main
#   feature/websocket
# * feature/cache

# ==================== 合并分支 ====================
# 1. 先切换到main分支
git checkout main

# 2. 合并feature/websocket到main
git merge feature/websocket

# 输出：
# Updating d4e5f6g..a1b2c3d
# Fast-forward
#  src/okx_websocket.cpp | 2500 +++++++++++++++++++++++
#  1 file changed, 2500 insertions(+)

# ==================== 删除分支 ====================
# 删除已合并的分支
git branch -d feature/websocket

# 强制删除未合并的分支
git branch -D feature/cache
```

### 4.4 查看差异

```bash
# ==================== 查看工作区修改 ====================
git diff
# 显示哪些文件改了什么

# ==================== 查看暂存区修改 ====================
git diff --staged

# ==================== 查看两个提交的差异 ====================
git diff a1b2c3d d4e5f6g

# ==================== 查看某个文件的历史修改 ====================
git log -p src/okx_websocket.cpp
```

### 4.5 撤销操作

```bash
# ==================== 撤销工作区的修改 ====================
# 恢复单个文件（慎用！修改会丢失）
git checkout -- src/okx_websocket.cpp
# 或
git restore src/okx_websocket.cpp

# ==================== 撤销暂存区的文件 ====================
# 从暂存区移除（但保留修改）
git reset HEAD src/okx_websocket.cpp
# 或
git restore --staged src/okx_websocket.cpp

# ==================== 撤销提交 ====================
# 撤销最后一次提交，但保留修改
git reset --soft HEAD^

# 撤销最后一次提交，修改退回工作区
git reset --mixed HEAD^

# 撤销最后一次提交，丢弃所有修改（慎用！）
git reset --hard HEAD^

# ==================== 修改最后一次提交 ====================
# 如果提交信息写错了
git commit --amend -m "新的提交信息"

# 如果忘记添加文件
git add forgotten_file.cpp
git commit --amend --no-edit
```

### 4.6 忽略文件（.gitignore）

创建 `.gitignore` 文件，告诉Git哪些文件不要追踪：

```bash
# 创建.gitignore文件
cat > .gitignore << 'EOF'
# ==================== 编译输出 ====================
build/
*.exe
*.dll
*.o
*.obj
*.a
*.so

# ==================== IDE配置 ====================
.vscode/
.idea/
*.swp
*.swo
*~

# ==================== 操作系统 ====================
.DS_Store
Thumbs.db
desktop.ini

# ==================== 临时文件 ====================
*.log
*.tmp
*.bak

# ==================== 敏感信息 ====================
config/config.json
*.env
secrets.txt

# ==================== 依赖库 ====================
node_modules/
vendor/

# ==================== 其他 ====================
.cache/
*.zip
*.tar.gz
EOF

# 添加到Git
git add .gitignore
git commit -m "添加.gitignore文件"
```

---

## 5. GitHub使用 {#github使用}

### 5.1 注册GitHub账号

1. 访问：https://github.com
2. 点击"Sign up"
3. 填写信息：
   - 用户名（建议简洁）
   - 邮箱（建议常用邮箱）
   - 密码（建议强密码）
4. 验证邮箱
5. 完成！

### 5.2 创建远程仓库

#### 方法1：在GitHub网站创建

1. 登录GitHub
2. 点击右上角"+"→"New repository"
3. 填写信息：
   ```
   Repository name: OKX-MT5-Arbitrage
   Description: OKX和MT5之间的套利交易系统
   Public/Private: 选Private（私有）
   不要勾选 "Initialize with README"
   ```
4. 点击"Create repository"

#### 方法2：使用GitHub CLI（可选）

```bash
# 安装GitHub CLI
# Windows (MSYS2):
pacman -S github-cli

# 登录
gh auth login

# 创建仓库
gh repo create OKX-MT5-Arbitrage --private
```

### 5.3 连接本地和远程仓库

```bash
# ==================== 添加远程仓库 ====================
git remote add origin https://github.com/你的用户名/OKX-MT5-Arbitrage.git

# 验证
git remote -v
# 输出：
# origin  https://github.com/你的用户名/OKX-MT5-Arbitrage.git (fetch)
# origin  https://github.com/你的用户名/OKX-MT5-Arbitrage.git (push)

# ==================== 首次推送 ====================
git push -u origin main

# 输出：
# Enumerating objects: 42, done.
# Counting objects: 100% (42/42), done.
# ...
# To https://github.com/你的用户名/OKX-MT5-Arbitrage.git
#  * [new branch]      main -> main

# 之后推送只需要
git push
```

### 5.4 克隆仓库

如果在另一台电脑上工作：

```bash
# 克隆仓库
git clone https://github.com/你的用户名/OKX-MT5-Arbitrage.git

# 进入目录
cd OKX-MT5-Arbitrage

# 查看远程仓库
git remote -v
```

### 5.5 拉取更新

```bash
# ==================== 拉取最新代码 ====================
git pull origin main
# 或简写
git pull

# ==================== 获取但不合并 ====================
git fetch origin

# 查看远程分支
git branch -r

# 手动合并
git merge origin/main
```

### 5.6 常用操作流程

```bash
# ==================== 每天开始工作前 ====================
git pull                    # 拉取最新代码

# ==================== 工作中 ====================
# 修改代码...
git status                  # 查看修改
git add .                   # 添加修改
git commit -m "完成XX功能"   # 提交

# ==================== 工作结束时 ====================
git push                    # 推送到GitHub

# ==================== 完整流程 ====================
git pull                    # 1. 拉取最新
# 修改代码...              # 2. 编写代码
git add .                   # 3. 添加修改
git commit -m "消息"        # 4. 提交
git push                    # 5. 推送
```

---

## 6. 实战：管理您的项目 {#实战管理您的项目}

### 6.1 初始化您的OKX-MT5项目

```bash
# ==================== 步骤1：进入项目目录 ====================
cd /path/to/OKX-MT5-Arbitrage

# ==================== 步骤2：初始化Git ====================
git init

# ==================== 步骤3：创建.gitignore ====================
cat > .gitignore << 'EOF'
# 编译输出
build/
*.exe
*.dll
*.o
*.a

# IDE配置
.vscode/
.idea/

# 临时文件
*.log
*.tmp

# 敏感信息
config/config.json
api_keys.txt
EOF

# ==================== 步骤4：添加所有文件 ====================
git add .

# ==================== 步骤5：首次提交 ====================
git commit -m "Initial commit: 项目基础框架（40%完成）

已完成：
- 配置系统
- 数据结构
- HTTP客户端
- 签名工具
- REST API
- WebSocket头文件

待完成：
- WebSocket实现
- 缓存层
- 策略引擎
- MT5集成"

# ==================== 步骤6：在GitHub创建仓库 ====================
# 访问 https://github.com/new
# 创建名为 OKX-MT5-Arbitrage 的私有仓库

# ==================== 步骤7：连接远程仓库 ====================
git remote add origin https://github.com/你的用户名/OKX-MT5-Arbitrage.git

# ==================== 步骤8：推送到GitHub ====================
git push -u origin main
```

### 6.2 使用分支开发WebSocket

```bash
# ==================== 创建并切换到WebSocket分支 ====================
git checkout -b feature/websocket-implementation

# ==================== 开发WebSocket ====================
# 创建/修改文件...
# src/okx_websocket.cpp
# tests/test_websocket.cpp

# ==================== 提交进度（可以多次提交） ====================
git add src/okx_websocket.cpp
git commit -m "WebSocket: 完成基础框架和连接管理"

git add tests/test_websocket.cpp
git commit -m "WebSocket: 添加测试程序"

# ==================== 推送分支到GitHub ====================
git push -u origin feature/websocket-implementation

# ==================== 完成后合并到main ====================
git checkout main
git merge feature/websocket-implementation
git push

# ==================== 删除已合并的分支 ====================
git branch -d feature/websocket-implementation
git push origin --delete feature/websocket-implementation
```

### 6.3 AI窗口交接流程

```bash
# ==================== AI窗口#1 结束时 ====================
# 1. 提交所有工作
git add .
git commit -m "AI窗口#1: WebSocket实现95%完成

完成：
- 基础框架（连接、断开、重连）
- 消息处理（Ticker、Depth、Order、Position）
- 订阅管理（公共和私有频道）
- 认证机制
- 心跳维护

待完成：
- 合并part1和part2
- 编译测试
- 功能验证"

# 2. 推送到GitHub
git push

# 3. 创建标签（重要！）
git tag -a v0.5-websocket-95 -m "WebSocket模块95%完成"
git push --tags

# ==================== AI窗口#2 开始时 ====================
# 1. 克隆或拉取
git pull

# 2. 查看最近提交
git log --oneline -5

# 3. 查看标签
git tag -l

# 4. 创建新分支继续工作
git checkout -b feature/websocket-integration

# 5. 继续开发...
```

### 6.4 回滚到之前的版本

```bash
# ==================== 查看历史 ====================
git log --oneline
# a1b2c3d (HEAD -> main) WebSocket实现95%
# d4e5f6g REST API完成
# g7h8i9j 初始提交

# ==================== 回到某个版本（查看） ====================
git checkout d4e5f6g
# 现在处于"分离头指针"状态，只是查看

# 返回最新版本
git checkout main

# ==================== 永久回滚（慎用！） ====================
# 方法1：保留历史记录
git revert a1b2c3d

# 方法2：删除历史（慎用！）
git reset --hard d4e5f6g
git push --force  # 强制推送（危险！）
```

---

## 7. AI协作最佳实践 {#ai协作最佳实践}

### 7.1 提交信息规范

**好的提交信息**：
```bash
git commit -m "feat: 实现WebSocket自动重连机制

- 添加指数退避算法
- 重连后自动恢复订阅
- 最多尝试10次重连
- 相关测试已通过"
```

**常用前缀**：
- `feat:` - 新功能
- `fix:` - 修复Bug
- `docs:` - 文档更新
- `test:` - 测试相关
- `refactor:` - 重构代码
- `chore:` - 杂项（配置等）

### 7.2 分支命名规范

```bash
# 功能分支
feature/websocket-implementation
feature/cache-layer
feature/strategy-engine

# 修复分支
fix/websocket-reconnect-bug
fix/memory-leak

# 文档分支
docs/api-documentation
docs/user-guide

# AI窗口分支
ai/window-1-websocket
ai/window-2-cache
```

### 7.3 每天的工作流程

```bash
# ==================== 早上开始工作 ====================
cd your-project
git pull                          # 拉取最新代码
git checkout -b feature/new-task  # 创建新分支

# ==================== 工作中（频繁提交） ====================
# 每完成一个小功能就提交
git add 相关文件
git commit -m "完成XX小功能"

# ==================== 中午休息前 ====================
git push -u origin feature/new-task  # 推送到GitHub备份

# ==================== 下午继续 ====================
git pull                          # 拉取可能的更新
# 继续工作...

# ==================== 晚上完成工作 ====================
git add .
git commit -m "今日工作完成"
git push                          # 推送到GitHub

# ==================== 功能完成后 ====================
git checkout main
git merge feature/new-task
git push
git branch -d feature/new-task    # 删除本地分支
```

### 7.4 标签管理（版本标记）

```bash
# ==================== 创建标签 ====================
# 轻量标签
git tag v0.5-websocket-complete

# 附注标签（推荐）
git tag -a v0.5 -m "WebSocket模块完成

主要更新：
- 完整的WebSocket实现
- 公共和私有频道支持
- 自动重连机制
- 心跳维护
- 完整测试"

# ==================== 查看标签 ====================
git tag
# v0.1-init
# v0.2-rest-api
# v0.3-config
# v0.5-websocket

# 查看标签详情
git show v0.5

# ==================== 推送标签 ====================
# 推送单个标签
git push origin v0.5

# 推送所有标签
git push --tags

# ==================== 切换到某个标签 ====================
git checkout v0.5
```

---

## 8. 常见问题 {#常见问题}

### Q1: 如何查看我改了什么？

```bash
# 查看工作区改动
git diff

# 查看某个文件改动
git diff src/okx_websocket.cpp

# 查看暂存区改动
git diff --staged
```

### Q2: 我想撤销刚才的修改怎么办？

```bash
# 还没git add（撤销工作区修改）
git restore 文件名

# 已经git add（撤销暂存）
git restore --staged 文件名

# 已经git commit（撤销提交）
git reset --soft HEAD^
```

### Q3: 我忘记切换分支就开始工作了怎么办？

```bash
# 方法1：暂存当前工作
git stash                    # 暂存
git checkout 正确的分支
git stash pop                # 恢复

# 方法2：直接创建新分支
git checkout -b 新分支名      # 当前修改会带到新分支
```

### Q4: 合并冲突怎么办？

```bash
# 合并时出现冲突
git merge feature/websocket
# Auto-merging src/okx_websocket.cpp
# CONFLICT (content): Merge conflict in src/okx_websocket.cpp

# 1. 打开冲突文件，会看到：
# <<<<<<< HEAD
# 你的代码
# =======
# 别人的代码
# >>>>>>> feature/websocket

# 2. 手动编辑，保留想要的代码，删除标记

# 3. 标记为已解决
git add src/okx_websocket.cpp

# 4. 完成合并
git commit
```

### Q5: 不小心提交了敏感信息怎么办？

```bash
# 如果还没push
git reset --soft HEAD^         # 撤销提交
# 删除敏感信息
git add .
git commit -m "重新提交"

# 如果已经push（需要重写历史，危险！）
# 1. 先从本地删除敏感信息
# 2. 使用 git filter-branch 或 BFG Repo-Cleaner
# 建议：联系GitHub support寻求帮助
```

### Q6: GitHub推送失败怎么办？

```bash
# 错误：Updates were rejected
git pull --rebase origin main  # 先拉取并变基
git push                       # 再推送

# 如果还是失败
git push --force               # 强制推送（慎用！）
```

### Q7: 如何删除远程分支？

```bash
# 删除本地分支
git branch -d 分支名

# 删除远程分支
git push origin --delete 分支名
```

### Q8: 如何查看某个文件的修改历史？

```bash
# 查看提交历史
git log --follow src/okx_websocket.cpp

# 查看每次修改的详细内容
git log -p src/okx_websocket.cpp

# 查看谁修改了哪一行
git blame src/okx_websocket.cpp
```

---

## 📝 快速参考卡

### 最常用命令

```bash
# ==================== 日常操作 ====================
git status              # 查看状态
git add .               # 添加所有修改
git commit -m "消息"    # 提交
git push                # 推送
git pull                # 拉取

# ==================== 分支操作 ====================
git branch              # 查看分支
git checkout -b 分支名  # 创建并切换分支
git merge 分支名        # 合并分支
git branch -d 分支名    # 删除分支

# ==================== 查看历史 ====================
git log                 # 查看提交历史
git log --oneline       # 简洁查看
git diff                # 查看修改

# ==================== 撤销操作 ====================
git restore 文件名      # 撤销工作区修改
git restore --staged 文件名  # 撤销暂存
git reset --soft HEAD^  # 撤销提交
```

### 救命命令

```bash
# 我不知道我在哪个分支
git branch

# 我不知道改了什么
git status
git diff

# 我想回到之前的某个版本
git log --oneline
git checkout 提交ID

# 我想放弃所有修改
git reset --hard HEAD

# 我想撤销最后一次提交
git reset --soft HEAD^

# 我的工作区乱了，想重新开始
git clean -fd           # 删除未跟踪的文件（慎用！）
git reset --hard HEAD   # 恢复到最后一次提交
```

---

## 🎉 恭喜！

您已经学会了Git和GitHub的基础使用！

**下一步**：
1. 初始化您的OKX-MT5项目
2. 推送到GitHub
3. 开始使用分支开发
4. 每天至少提交一次

**记住**：
- 📸 频繁提交（commit early, commit often）
- 🌿 使用分支开发新功能
- ☁️ 定期推送到GitHub备份
- 📝 写清楚的提交信息

**遇到问题**：
- 查看本文档的"常见问题"部分
- Google搜索错误信息
- 访问：https://stackoverflow.com

---

**Happy Coding!** 🚀
