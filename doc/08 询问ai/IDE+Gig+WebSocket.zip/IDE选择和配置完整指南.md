# IDE 选择和配置完整指南

> **目标**: 选择最适合您的IDE并完成配置  
> **推荐IDE**: Visual Studio Code (VS Code)  
> **时间**: 30分钟

---

## 📊 IDE对比与推荐

### 适合您项目的IDE对比

| IDE | 免费 | 易用性 | Git集成 | C++支持 | AI支持 | 推荐度 |
|-----|------|--------|---------|---------|--------|--------|
| **VS Code** | ✅ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| Visual Studio | ✅ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ |
| CLion | ❌($) | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ |
| Qt Creator | ✅ | ⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐ |
| Code::Blocks | ✅ | ⭐⭐ | ⭐⭐ | ⭐⭐⭐ | ⭐ | ⭐⭐ |

### 🏆 我的推荐：Visual Studio Code

**为什么推荐VS Code？**

✅ **完全免费开源**
✅ **轻量快速**（启动只需1-2秒）
✅ **Git集成完美**（内置Git支持）
✅ **插件生态丰富**（C++、Python、Web都支持）
✅ **跨平台**（Windows、Mac、Linux）
✅ **AI协作友好**（支持GitHub Copilot、Continue等）
✅ **学习成本低**（界面简洁直观）
✅ **社区活跃**（问题容易找到答案）

**特别适合您因为**：
- 🤖 **AI协作**：可以安装AI插件辅助编程
- 📦 **项目管理**：与Git/GitHub无缝集成
- 🔧 **C++支持好**：通过插件支持C++开发
- 📝 **Markdown支持**：方便编写文档

---

## 🚀 VS Code 安装和配置

### 1. 下载和安装

#### Windows安装

1. **下载**
   - 访问：https://code.visualstudio.com/
   - 点击"Download for Windows"
   - 选择"System Installer"（推荐）

2. **安装**
   - 运行下载的安装程序
   - **重要**：安装时勾选以下选项：
     - ✅ 添加到PATH（重要！）
     - ✅ 将"通过Code打开"添加到资源管理器右键菜单
     - ✅ 注册为支持的文件类型的编辑器

3. **验证安装**
   ```bash
   # 打开命令行
   code --version
   # 输出：1.85.0
   ```

### 2. 中文化（可选）

1. 打开VS Code
2. 按 `Ctrl + Shift + P` 打开命令面板
3. 输入 "Configure Display Language"
4. 选择 "Install additional languages"
5. 搜索 "Chinese" 并安装
6. 重启VS Code

### 3. 必装插件

#### 3.1 C/C++ 开发插件

**C/C++ Extension Pack**（一键安装包）

1. 点击左侧扩展图标（或按 `Ctrl + Shift + X`）
2. 搜索 "C/C++ Extension Pack"
3. 点击"Install"

**包含的插件**：
- ✅ C/C++ - 核心C++支持
- ✅ CMake - CMake支持
- ✅ CMake Tools - CMake工具集成

**单独安装（如果上面的包有问题）**：
- `C/C++` by Microsoft
- `CMake` by twxs
- `CMake Tools` by Microsoft

#### 3.2 Git 插件

**GitLens** ⭐⭐⭐⭐⭐（强烈推荐）

功能：
- 查看每行代码的修改历史
- 可视化分支和提交
- 比较不同版本
- 强大的Git集成

安装：
1. 搜索 "GitLens"
2. 安装 by GitKraken

**Git Graph**（可选）

功能：
- 可视化Git提交树
- 直观的分支管理

#### 3.3 代码辅助插件

**GitHub Copilot**（AI编程助手）

- **价格**：$10/月（学生免费）
- **功能**：AI自动补全代码
- **是否需要**：可选，但强烈推荐

**Continue**（免费AI助手）

- **价格**：免费
- **功能**：类似Copilot，支持多个AI模型
- **推荐**：如果不想付费，用这个

安装Continue：
1. 搜索 "Continue"
2. 安装后按 `Ctrl + L` 唤起
3. 可以使用Claude、GPT等模型

#### 3.4 其他实用插件

| 插件名 | 功能 | 推荐度 |
|--------|------|--------|
| **Better Comments** | 彩色注释 | ⭐⭐⭐⭐⭐ |
| **Bracket Pair Colorizer** | 括号配对高亮 | ⭐⭐⭐⭐⭐ |
| **Error Lens** | 行内显示错误 | ⭐⭐⭐⭐⭐ |
| **TODO Highlight** | 高亮TODO | ⭐⭐⭐⭐ |
| **Code Spell Checker** | 拼写检查 | ⭐⭐⭐⭐ |
| **Markdown All in One** | Markdown增强 | ⭐⭐⭐⭐⭐ |
| **Path Intellisense** | 路径自动补全 | ⭐⭐⭐⭐ |
| **indent-rainbow** | 缩进彩虹色 | ⭐⭐⭐ |

**一键安装命令**：
```bash
# 打开命令行，执行以下命令
code --install-extension ms-vscode.cpptools-extension-pack
code --install-extension eamodio.gitlens
code --install-extension mhutchie.git-graph
code --install-extension aaron-bond.better-comments
code --install-extension usernamehw.errorlens
code --install-extension wayou.vscode-todo-highlight
code --install-extension yzhang.markdown-all-in-one
code --install-extension christian-kohler.path-intellisense
```

### 4. VS Code 配置

#### 4.1 打开设置

方法1：`Ctrl + ,`  
方法2：文件 → 首选项 → 设置

#### 4.2 推荐配置

点击右上角的"打开设置(JSON)"图标，添加以下配置：

```json
{
    // ==================== 编辑器基础设置 ====================
    "editor.fontSize": 14,
    "editor.lineHeight": 22,
    "editor.tabSize": 4,
    "editor.insertSpaces": true,
    "editor.wordWrap": "on",
    "editor.minimap.enabled": true,
    "editor.renderWhitespace": "boundary",
    "editor.rulers": [80, 120],
    
    // ==================== 代码提示 ====================
    "editor.suggestSelection": "first",
    "editor.quickSuggestions": {
        "other": true,
        "comments": true,
        "strings": true
    },
    
    // ==================== 代码格式化 ====================
    "editor.formatOnSave": true,
    "editor.formatOnPaste": true,
    "[cpp]": {
        "editor.defaultFormatter": "ms-vscode.cpptools"
    },
    
    // ==================== 文件设置 ====================
    "files.autoSave": "afterDelay",
    "files.autoSaveDelay": 1000,
    "files.trimTrailingWhitespace": true,
    "files.insertFinalNewline": true,
    
    // ==================== Git设置 ====================
    "git.autofetch": true,
    "git.confirmSync": false,
    "git.enableSmartCommit": true,
    "gitlens.hovers.currentLine.over": "line",
    
    // ==================== 终端设置 ====================
    "terminal.integrated.defaultProfile.windows": "Git Bash",
    "terminal.integrated.fontSize": 12,
    
    // ==================== C/C++设置 ====================
    "C_Cpp.default.cppStandard": "c++17",
    "C_Cpp.default.intelliSenseMode": "gcc-x64",
    "C_Cpp.errorSquiggles": "enabled",
    
    // ==================== CMake设置 ====================
    "cmake.configureOnOpen": true,
    "cmake.buildDirectory": "${workspaceFolder}/build",
    
    // ==================== 其他 ====================
    "workbench.startupEditor": "newUntitledFile",
    "explorer.confirmDelete": false,
    "explorer.confirmDragAndDrop": false
}
```

### 5. C++ 开发配置

#### 5.1 配置编译器

创建 `.vscode/c_cpp_properties.json`：

```json
{
    "configurations": [
        {
            "name": "Win32",
            "includePath": [
                "${workspaceFolder}/**",
                "${workspaceFolder}/include",
                "C:/msys64/mingw64/include/**"
            ],
            "defines": [
                "_DEBUG",
                "UNICODE",
                "_UNICODE"
            ],
            "compilerPath": "C:/msys64/mingw64/bin/g++.exe",
            "cStandard": "c17",
            "cppStandard": "c++17",
            "intelliSenseMode": "gcc-x64"
        }
    ],
    "version": 4
}
```

#### 5.2 配置CMake

创建 `.vscode/settings.json`（项目级配置）：

```json
{
    "cmake.configureSettings": {
        "CMAKE_BUILD_TYPE": "Debug"
    },
    "cmake.generator": "Ninja",
    "cmake.buildDirectory": "${workspaceFolder}/build"
}
```

#### 5.3 配置任务（编译快捷键）

创建 `.vscode/tasks.json`：

```json
{
    "version": "2.0.0",
    "tasks": [
        {
            "label": "CMake: Configure",
            "type": "shell",
            "command": "cmake",
            "args": [
                "-B",
                "${workspaceFolder}/build",
                "-G",
                "Ninja"
            ],
            "problemMatcher": [],
            "group": "build"
        },
        {
            "label": "CMake: Build",
            "type": "shell",
            "command": "cmake",
            "args": [
                "--build",
                "${workspaceFolder}/build"
            ],
            "problemMatcher": ["$gcc"],
            "group": {
                "kind": "build",
                "isDefault": true
            }
        },
        {
            "label": "CMake: Clean",
            "type": "shell",
            "command": "cmake",
            "args": [
                "--build",
                "${workspaceFolder}/build",
                "--target",
                "clean"
            ],
            "problemMatcher": []
        }
    ]
}
```

现在可以使用 `Ctrl + Shift + B` 快速编译！

#### 5.4 配置调试

创建 `.vscode/launch.json`：

```json
{
    "version": "0.2.0",
    "configurations": [
        {
            "name": "Debug Test WebSocket",
            "type": "cppdbg",
            "request": "launch",
            "program": "${workspaceFolder}/build/test_websocket.exe",
            "args": [],
            "stopAtEntry": false,
            "cwd": "${workspaceFolder}",
            "environment": [],
            "externalConsole": false,
            "MIMode": "gdb",
            "miDebuggerPath": "C:/msys64/mingw64/bin/gdb.exe",
            "setupCommands": [
                {
                    "description": "Enable pretty-printing for gdb",
                    "text": "-enable-pretty-printing",
                    "ignoreFailures": true
                }
            ],
            "preLaunchTask": "CMake: Build"
        }
    ]
}
```

现在可以使用 `F5` 启动调试！

---

## 🎨 VS Code 使用技巧

### 基础操作

| 功能 | 快捷键 | 说明 |
|------|--------|------|
| **命令面板** | `Ctrl + Shift + P` | 执行任何命令 |
| **快速打开文件** | `Ctrl + P` | 输入文件名快速打开 |
| **侧边栏** | `Ctrl + B` | 显示/隐藏侧边栏 |
| **终端** | `Ctrl + `` | 打开/关闭终端 |
| **分屏** | `Ctrl + \` | 左右分屏 |

### 编辑操作

| 功能 | 快捷键 | 说明 |
|------|--------|------|
| **多光标** | `Alt + Click` | 在多个位置编辑 |
| **选中相同内容** | `Ctrl + D` | 依次选中相同内容 |
| **注释/取消注释** | `Ctrl + /` | 行注释 |
| **块注释** | `Shift + Alt + A` | 块注释 |
| **复制行** | `Shift + Alt + ↓` | 向下复制当前行 |
| **移动行** | `Alt + ↑/↓` | 上下移动行 |
| **删除行** | `Ctrl + Shift + K` | 删除整行 |
| **格式化代码** | `Shift + Alt + F` | 自动格式化 |

### Git 操作

| 功能 | 快捷键 | 说明 |
|------|--------|------|
| **源代码管理** | `Ctrl + Shift + G` | 打开Git面板 |
| **提交** | `Ctrl + Enter` | 在Git面板中提交 |
| **查看修改** | 点击文件 | 在Git面板中 |

### 导航操作

| 功能 | 快捷键 | 说明 |
|------|--------|------|
| **跳转到定义** | `F12` | 跳转到函数定义 |
| **返回上一位置** | `Alt + ←` | 后退 |
| **前进** | `Alt + →` | 前进 |
| **查找引用** | `Shift + F12` | 查找所有引用 |
| **全局搜索** | `Ctrl + Shift + F` | 在所有文件中搜索 |
| **文件内搜索** | `Ctrl + F` | 当前文件搜索 |

### 调试操作

| 功能 | 快捷键 | 说明 |
|------|--------|------|
| **开始调试** | `F5` | 开始/继续 |
| **单步跳过** | `F10` | Step Over |
| **单步进入** | `F11` | Step Into |
| **单步跳出** | `Shift + F11` | Step Out |
| **设置断点** | `F9` | 切换断点 |

---

## 🔧 项目设置

### 1. 打开您的项目

```bash
# 方法1：命令行
cd /path/to/OKX-MT5-Arbitrage
code .

# 方法2：右键菜单
# 在文件夹上右键 → "通过Code打开"

# 方法3：VS Code内
# 文件 → 打开文件夹
```

### 2. 创建工作区配置

在项目根目录创建 `.vscode` 文件夹：

```bash
mkdir .vscode
cd .vscode
```

然后创建上面提到的配置文件：
- `c_cpp_properties.json` - C++配置
- `settings.json` - 项目设置
- `tasks.json` - 编译任务
- `launch.json` - 调试配置

### 3. 推荐的项目结构

```
OKX-MT5-Arbitrage/
├── .vscode/                 # VS Code配置
│   ├── c_cpp_properties.json
│   ├── settings.json
│   ├── tasks.json
│   └── launch.json
├── .git/                    # Git仓库
├── .gitignore              # Git忽略文件
├── include/                # 头文件
├── src/                    # 源文件
├── tests/                  # 测试
├── config/                 # 配置文件
├── docs/                   # 文档
├── build/                  # 编译输出（不提交）
├── CMakeLists.txt          # CMake配置
└── README.md               # 项目说明
```

---

## 🎯 VS Code + Git 工作流

### 界面布局

```
┌─────────────────────────────────────────────────┐
│  文件 编辑 选择 视图 转到 运行 终端 帮助        │ ← 菜单栏
├──┬──────────────────────────────────────────────┤
│  │                                               │
│文│  编辑区域                                     │
│件│  - 代码编辑                                   │
│资│  - Git差异对比                                │
│源│  - 分屏编辑                                   │
│管│                                               │
│理│                                               │
│  │                                               │
│Git                                               │
│源│                                               │
│代│                                               │
│码│                                               │
│管│                                               │
│理│                                               │
│  │                                               │
│搜│                                               │
│索│                                               │
│  │                                               │
├──┴──────────────────────────────────────────────┤
│  终端 / 输出 / 调试控制台                       │ ← 底部面板
└─────────────────────────────────────────────────┘
```

### Git操作演示

#### 1. 查看修改

1. 点击左侧"源代码管理"图标（或 `Ctrl + Shift + G`）
2. 看到所有修改的文件
3. 点击文件名查看差异（左边旧版本，右边新版本）

#### 2. 提交更改

1. 在源代码管理面板
2. 在"消息"框输入提交信息
3. 点击"✓提交"（或 `Ctrl + Enter`）

#### 3. 推送到GitHub

1. 提交后，点击"..."菜单
2. 选择"推送"
3. 或点击底部状态栏的"↑"图标

#### 4. 拉取更新

1. 点击底部状态栏的"↓"图标
2. 或在"..."菜单选择"拉取"

#### 5. 分支管理

1. 点击左下角的分支名（如"main"）
2. 选择操作：
   - 创建新分支
   - 切换分支
   - 合并分支

### GitLens 功能

安装GitLens后，你会看到：

**行内信息**：
```cpp
void Connect() {  // John Doe, 2 days ago: 添加连接功能
    // 代码...
}
```

**文件历史**：
- 右键文件 → "Open File History"
- 查看所有修改记录

**代码追溯**：
- 点击行号左侧的GitLens图标
- 看到这行代码的完整修改历史

---

## 💡 高级技巧

### 1. Snippets（代码片段）

创建自定义代码片段：

1. 文件 → 首选项 → 配置用户代码片段
2. 选择 "cpp.json"
3. 添加：

```json
{
    "Function Template": {
        "prefix": "func",
        "body": [
            "/**",
            " * @brief ${1:函数说明}",
            " * @param ${2:参数} ${3:参数说明}",
            " * @return ${4:返回值说明}",
            " */",
            "${5:返回类型} ${6:函数名}(${7:参数列表}) {",
            "    ${8:// 实现}",
            "    return ${9:返回值};",
            "}"
        ],
        "description": "函数模板"
    },
    "Class Template": {
        "prefix": "class",
        "body": [
            "/**",
            " * @brief ${1:类说明}",
            " */",
            "class ${2:ClassName} {",
            "public:",
            "    ${2:ClassName}();",
            "    ~${2:ClassName}();",
            "    ",
            "private:",
            "    ${3:// 私有成员}",
            "};"
        ],
        "description": "类模板"
    }
}
```

使用：输入 `func` 或 `class` 然后按 `Tab`

### 2. 多光标编辑

选中一个变量，按 `Ctrl + D` 依次选中所有相同的：

```cpp
// 选中 old_name，按3次Ctrl+D
old_name = value;
old_name.method();
return old_name;

// 全部选中后，直接输入new_name，同时修改所有
```

### 3. 快速重构

- `F2`：重命名符号
- `Ctrl + .`：快速修复
- `Alt + Shift + F`：格式化整个文件

### 4. 工作区管理

保存当前工作状态：

1. 文件 → 将工作区另存为
2. 保存为 `project.code-workspace`
3. 下次直接打开此文件即可恢复所有设置

---

## 🆚 其他IDE简介（如果您想尝试）

### Visual Studio（适合大型项目）

**优点**：
- 功能最强大
- C++支持最好
- 调试功能完善

**缺点**：
- 体积巨大（几十GB）
- 启动较慢
- 只支持Windows

**何时选择**：
- 需要开发Windows桌面应用
- 需要最强的C++调试
- 电脑配置好（16GB+内存）

### CLion（专业C++ IDE）

**优点**：
- 专为C++设计
- 智能提示强大
- 重构功能好

**缺点**：
- 收费（$199/年）
- 占用资源多
- 学习曲线陡

**何时选择**：
- 愿意付费
- 专注C++开发
- 需要强大的重构功能

---

## 📚 学习资源

### VS Code 官方文档
- 英文：https://code.visualstudio.com/docs
- 中文：https://code.visualstudio.com/docs?locale=zh-cn

### 视频教程
- B站搜索："VS Code C++ 教程"
- YouTube搜索："VS Code C++ Tutorial"

### 快捷键PDF
- 官方快捷键参考：Help → Keyboard Shortcuts Reference

---

## ✅ 检查清单

完成以下检查，确保配置正确：

- [ ] VS Code已安装
- [ ] 中文语言包已安装（可选）
- [ ] C/C++ Extension Pack已安装
- [ ] GitLens已安装
- [ ] Git已配置（`git --version`能看到版本）
- [ ] 项目文件夹已在VS Code中打开
- [ ] `.vscode`配置文件已创建
- [ ] 能使用 `Ctrl + Shift + B` 编译
- [ ] 能使用 `F5` 调试
- [ ] Git面板能看到文件修改

---

## 🎉 总结

**您现在拥有了**：
✅ 专业的C++开发环境  
✅ 完美的Git集成  
✅ 强大的代码提示  
✅ 便捷的调试功能  
✅ AI辅助编程能力

**下一步**：
1. 打开您的项目
2. 配置.vscode文件夹
3. 尝试编译和调试
4. 使用Git提交代码

**记住最重要的快捷键**：
- `Ctrl + P`：快速打开文件
- `Ctrl + Shift + P`：命令面板
- `Ctrl + Shift + G`：Git面板
- `Ctrl + B`：显示/隐藏侧边栏
- `F5`：调试
- `Ctrl + Shift + B`：编译

---

**Happy Coding!** 🚀
