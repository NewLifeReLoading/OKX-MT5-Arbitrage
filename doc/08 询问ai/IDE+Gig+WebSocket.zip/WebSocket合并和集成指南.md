# WebSocket模块合并和集成指南

> **目的**: 将WebSocket的两个部分合并为完整的实现，并集成到项目中  
> **时间**: 约30分钟  
> **难度**: 中等

---

## 📋 需要完成的文件

### 1. 完整的WebSocket实现
- **输入**: `okx_websocket_part1.cpp` + `okx_websocket_part2.cpp`
- **输出**: `src/okx_websocket.cpp`
- **操作**: 合并两个文件

### 2. 测试程序
- **输入**: `test_websocket.cpp`
- **输出**: `tests/test_websocket.cpp`
- **操作**: 复制文件

### 3. 更新构建配置
- **文件**: `CMakeLists.txt`
- **操作**: 添加WebSocket++支持

---

## 🔧 步骤1：合并WebSocket实现

### 1.1 创建完整的okx_websocket.cpp

将两个part文件合并为一个完整文件：

```bash
# 在项目根目录
cd /path/to/OKX-MT5-Arbitrage

# 创建完整的cpp文件
cat okx_websocket_part1.cpp okx_websocket_part2.cpp > src/okx_websocket.cpp
```

或者手动合并：

1. 打开 `okx_websocket_part1.cpp`
2. 删除文件末尾的"文件未完成提示"部分
3. 将 `okx_websocket_part2.cpp` 的内容（从 `// ==================== Public Channel Subscriptions ====================` 开始）追加到part1的末尾
4. 删除part2文件开头的注释
5. 保存为 `src/okx_websocket.cpp`

### 1.2 验证代码完整性

确保合并后的文件包含所有必要的部分：

```cpp
// 应该包含的主要部分：
// 1. 头文件包含
// 2. 构造函数和析构函数
// 3. Initialize() 和 Connect()
// 4. 事件处理器 (OnOpen, OnClose, OnFail, OnMessage)
// 5. 消息处理 (ProcessMessage, ProcessTickerMessage, ProcessDepthMessage等)
// 6. 公共频道订阅 (SubscribeTicker, SubscribeDepth)
// 7. 私有频道订阅 (SubscribeOrders, SubscribePositions, SubscribeAccount)
// 8. 认证 (Authenticate, GenerateAuthSignature)
// 9. 重连 (ReconnectionLoop, AttemptReconnect)
// 10. 心跳 (PingLoop, SendPing)
// 11. 辅助函数 (RunEventLoop, StopEventLoop, GetStatistics)
```

---

## 📦 步骤2：安装WebSocket++库

### 2.1 下载WebSocket++

WebSocket++是纯头文件库，无需编译：

```bash
# 方法1：使用Git克隆
git clone https://github.com/zaphoyd/websocketpp.git
cp -r websocketpp/websocketpp include/

# 方法2：下载Release版本
# 访问：https://github.com/zaphoyd/websocketpp/releases
# 下载最新版本的zip文件
# 解压后将websocketpp目录复制到include/
```

### 2.2 验证安装

```bash
ls include/websocketpp/
# 应该看到：
# - config/
# - client.hpp
# - server.hpp
# - 其他头文件...
```

---

## 🛠️ 步骤3：更新CMakeLists.txt

### 3.1 添加WebSocket++支持

在 `CMakeLists.txt` 中添加以下内容：

```cmake
# ==================== WebSocket++ Configuration ====================

# WebSocket++ requires Boost.Asio (header-only)
find_package(Boost REQUIRED)
if(Boost_FOUND)
    include_directories(${Boost_INCLUDE_DIRS})
    message(STATUS "Boost found: ${Boost_VERSION}")
else()
    message(FATAL_ERROR "Boost not found. Please install Boost.")
endif()

# WebSocket++ headers
include_directories(${CMAKE_SOURCE_DIR}/include/websocketpp)

# ==================== WebSocket Source Files ====================

# Add WebSocket source to library
set(OKX_API_SOURCES
    ${OKX_API_SOURCES}
    src/okx_websocket.cpp
)

# ==================== WebSocket Test ====================

# WebSocket test program
add_executable(test_websocket 
    tests/test_websocket.cpp
)

target_link_libraries(test_websocket 
    okx_api
    pthread  # Required for threading
)

# Copy to build directory for easy access
add_custom_command(TARGET test_websocket POST_BUILD
    COMMAND ${CMAKE_COMMAND} -E copy
    $<TARGET_FILE:test_websocket>
    ${CMAKE_SOURCE_DIR}/build/
)
```

### 3.2 完整的CMakeLists.txt示例

```cmake
cmake_minimum_required(VERSION 3.20)
project(OKX_MT5_Arbitrage)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# ==================== Dependencies ====================

# cURL
find_package(CURL REQUIRED)
if(CURL_FOUND)
    include_directories(${CURL_INCLUDE_DIRS})
    message(STATUS "cURL found: ${CURL_VERSION_STRING}")
endif()

# OpenSSL
find_package(OpenSSL REQUIRED)
if(OPENSSL_FOUND)
    include_directories(${OPENSSL_INCLUDE_DIR})
    message(STATUS "OpenSSL found: ${OPENSSL_VERSION}")
endif()

# Boost (for WebSocket++)
find_package(Boost REQUIRED)
if(Boost_FOUND)
    include_directories(${Boost_INCLUDE_DIRS})
    message(STATUS "Boost found: ${Boost_VERSION}")
endif()

# nlohmann/json
include(FetchContent)
FetchContent_Declare(json
    URL https://github.com/nlohmann/json/releases/download/v3.11.2/json.tar.xz
)
FetchContent_MakeAvailable(json)

# WebSocket++
include_directories(${CMAKE_SOURCE_DIR}/include/websocketpp)

# ==================== Include Directories ====================

include_directories(${CMAKE_SOURCE_DIR}/include)

# ==================== Source Files ====================

set(OKX_API_SOURCES
    src/config.cpp
    src/http_client.cpp
    src/okx_signer.cpp
    src/okx_rest_api.cpp
    src/okx_websocket.cpp
)

# ==================== Library ====================

add_library(okx_api STATIC ${OKX_API_SOURCES})

target_link_libraries(okx_api
    CURL::libcurl
    OpenSSL::SSL
    OpenSSL::Crypto
    nlohmann_json::nlohmann_json
)

# ==================== Test Programs ====================

# Config test
add_executable(test_config tests/test_config.cpp)
target_link_libraries(test_config okx_api)

# API validator
add_executable(test_api_validator tests/test_api_validator.cpp)
target_link_libraries(test_api_validator okx_api)

# WebSocket test
add_executable(test_websocket tests/test_websocket.cpp)
target_link_libraries(test_websocket okx_api pthread)

# ==================== Installation ====================

install(TARGETS okx_api
    LIBRARY DESTINATION lib
    ARCHIVE DESTINATION lib
)

install(DIRECTORY include/
    DESTINATION include
    FILES_MATCHING PATTERN "*.h"
)
```

---

## ⚙️ 步骤4：编译项目

### 4.1 清理旧的构建

```bash
cd build
rm -rf *
```

### 4.2 重新生成Makefile

```bash
cmake ..
```

预期输出：
```
-- Found CURL: 8.4.0
-- Found OpenSSL: 3.1.4
-- Found Boost: 1.82.0
-- Configuring done
-- Generating done
```

### 4.3 编译

```bash
cmake --build .
# 或
make
```

预期输出：
```
[ 10%] Building CXX object CMakeFiles/okx_api.dir/src/config.cpp.o
[ 20%] Building CXX object CMakeFiles/okx_api.dir/src/http_client.cpp.o
[ 30%] Building CXX object CMakeFiles/okx_api.dir/src/okx_signer.cpp.o
[ 40%] Building CXX object CMakeFiles/okx_api.dir/src/okx_rest_api.cpp.o
[ 50%] Building CXX object CMakeFiles/okx_api.dir/src/okx_websocket.cpp.o
[ 60%] Linking CXX static library libokx_api.a
[ 60%] Built target okx_api
[ 70%] Building CXX object CMakeFiles/test_config.dir/tests/test_config.cpp.o
[ 80%] Linking CXX executable test_config
[ 80%] Built target test_config
[ 90%] Building CXX object CMakeFiles/test_websocket.dir/tests/test_websocket.cpp.o
[100%] Linking CXX executable test_websocket
[100%] Built target test_websocket
```

### 4.4 检查编译结果

```bash
ls -lh
# 应该看到：
# - libokx_api.a (静态库)
# - test_config.exe
# - test_api_validator.exe
# - test_websocket.exe (新增)
```

---

## 🧪 步骤5：测试WebSocket

### 5.1 运行测试程序

```bash
cd ..
./build/test_websocket
```

### 5.2 选择测试

```
========================================
  OKX WebSocket Test Program
========================================

Select test:
  1. Public Channels (Ticker & Depth)
  2. Private Channels (Orders, Positions, Account)
  3. Auto-Reconnection Test
  0. Exit

Enter choice: 1
```

### 5.3 预期输出

```
==================================================
  TEST 1: Public Channels (Ticker & Depth)
==================================================

[Test] WebSocket initialized
[Test] Connected to WebSocket
[Test] Subscribing to ticker for XAUT-USDT-SWAP...
[WebSocket] Subscribed to: tickers
[Test] Subscribing to depth (top 5) for XAUT-USDT-SWAP...
[WebSocket] Subscribed to: books5
[Test] Listening for updates for 30 seconds...

[Ticker Update]
  Instrument: XAUT-USDT-SWAP
  Last:       2089.50
  Bid:        2089.40 x 10.0
  Ask:        2089.60 x 8.5
  24h High:   2095.80
  24h Low:    2085.20
  24h Volume: 125430.0
  Time:       2025-11-05 15:30:45.123

[Depth Update]
  Instrument: XAUT-USDT-SWAP
  Asks (Sellers):
    2089.90 x 15.0
    2089.80 x 20.0
    2089.70 x 12.5
    2089.65 x 8.0
    2089.60 x 10.0
  -------- Spread --------
  Spread: 0.20
  Bids (Buyers):
    2089.40 x 18.0
    2089.30 x 22.0
    2089.20 x 16.5
    2089.10 x 14.0
    2089.00 x 20.0
  Time: 2025-11-05 15:30:45.234

[Statistics]
  Connected:        Yes
  Messages Sent:    3
  Messages Received: 45
  Subscriptions:    2
  Reconnections:    0
```

---

## 🐛 常见问题排查

### 问题1：找不到WebSocket++头文件

**错误**:
```
fatal error: websocketpp/config/asio_client.hpp: No such file or directory
```

**解决**:
```bash
# 检查WebSocket++是否安装
ls include/websocketpp/

# 如果没有，重新安装
git clone https://github.com/zaphoyd/websocketpp.git
cp -r websocketpp/websocketpp include/
```

### 问题2：找不到Boost

**错误**:
```
CMake Error: Could NOT find Boost
```

**解决**:
```bash
# Windows (MSYS2)
pacman -S mingw-w64-x86_64-boost

# Linux (Ubuntu/Debian)
sudo apt-get install libboost-all-dev

# macOS
brew install boost
```

### 问题3：链接错误（pthread）

**错误**:
```
undefined reference to `pthread_create'
```

**解决**:
在 `CMakeLists.txt` 中确保链接了pthread：
```cmake
target_link_libraries(test_websocket okx_api pthread)
```

### 问题4：SSL证书验证失败

**错误**:
```
[WebSocket] Connection failed: certificate verify failed
```

**解决**:
在 `OnTLSInit()` 函数中已经设置了 `verify_none`，如果仍然失败：
```cpp
ctx->set_verify_mode(asio::ssl::verify_none);
```

### 问题5：连接超时

**错误**:
```
[WebSocket] Connection timeout
```

**检查**:
1. 网络连接是否正常
2. 防火墙是否阻止了WebSocket连接（端口8443）
3. URL是否正确（模拟盘vs实盘）

---

## ✅ 验证清单

完成所有步骤后，确认以下内容：

- [ ] WebSocket实现文件已合并（src/okx_websocket.cpp）
- [ ] WebSocket++库已安装（include/websocketpp/）
- [ ] Boost库已安装
- [ ] CMakeLists.txt已更新
- [ ] 项目编译成功（无错误）
- [ ] test_websocket程序已生成
- [ ] 测试程序运行成功
- [ ] 能够接收实时Ticker更新
- [ ] 能够接收实时Depth更新
- [ ] 统计信息正确显示

---

## 📝 下一步

WebSocket模块完成后，可以继续：

1. **缓存层**（阶段4）
   - SQLite数据库集成
   - 数据存储和查询

2. **策略引擎**（阶段5）
   - 网格策略实现
   - 开平仓逻辑
   - 盈亏计算

3. **MT5集成**（阶段6）
   - MT5 API封装
   - DLL导出
   - MQL5 EA脚本

---

## 🎉 完成标志

当看到以下输出时，WebSocket模块就完成了：

```
✅ 编译成功
✅ 测试通过
✅ 能够接收实时数据
✅ 自动重连工作正常
✅ 心跳维护正常
```

**恭喜！WebSocket模块已完成，项目进度约50%！** 🚀

---

**文档结束**
