/**
 * @file okx_websocket.cpp
 * @brief OKX WebSocket Client Implementation
 * @author AI Assistant
 * @date 2025-11-05
 * 
 * 实现说明：
 * - 使用WebSocket++库进行WebSocket通信
 * - 支持公共频道（行情）和私有频道（订单、持仓）
 * - 自动重连机制（指数退避）
 * - 心跳维护（每20秒ping一次）
 * - 线程安全的回调处理
 */

#include "okx_websocket.h"
#include <iostream>
#include <sstream>
#include <chrono>
#include <thread>
#include <openssl/hmac.h>
#include <openssl/evp.h>
#include <cstring>
#include <iomanip>

using namespace std;
using json = nlohmann::json;

// ==================== Constructor & Destructor ====================

OKXWebSocket::OKXWebSocket() 
    : is_connected_(false)
    , should_reconnect_(true) {
    
    // Initialize WebSocket client
    ws_client_.clear_access_channels(websocketpp::log::alevel::all);
    ws_client_.set_access_channels(websocketpp::log::alevel::connect | 
                                    websocketpp::log::alevel::disconnect);
    
    ws_client_.clear_error_channels(websocketpp::log::elevel::all);
    ws_client_.set_error_channels(websocketpp::log::elevel::warn | 
                                   websocketpp::log::elevel::rerror | 
                                   websocketpp::log::elevel::fatal);
    
    // Initialize Asio
    ws_client_.init_asio();
    
    // Set event handlers
    ws_client_.set_open_handler([this](websocketpp::connection_hdl hdl) {
        this->OnOpen(hdl);
    });
    
    ws_client_.set_close_handler([this](websocketpp::connection_hdl hdl) {
        this->OnClose(hdl);
    });
    
    ws_client_.set_fail_handler([this](websocketpp::connection_hdl hdl) {
        this->OnFail(hdl);
    });
    
    ws_client_.set_message_handler([this](websocketpp::connection_hdl hdl, 
                                          WebSocketClient::message_ptr msg) {
        this->OnMessage(hdl, msg);
    });
    
    ws_client_.set_tls_init_handler([this](websocketpp::connection_hdl hdl) {
        return this->OnTLSInit(hdl);
    });
}

OKXWebSocket::~OKXWebSocket() {
    Disconnect();
}

// ==================== Initialization & Connection ====================

bool OKXWebSocket::Initialize(const WSConfig& config) {
    lock_guard<mutex> lock(mutex_);
    
    config_ = config;
    
    // Create signer if credentials provided
    if (!config_.api_key.empty() && !config_.secret_key.empty()) {
        signer_ = make_unique<OKXSigner>(
            config_.api_key, 
            config_.secret_key, 
            config_.passphrase
        );
    }
    
    return true;
}

bool OKXWebSocket::Connect() {
    lock_guard<mutex> lock(mutex_);
    
    if (is_connected_) {
        cerr << "[WebSocket] Already connected" << endl;
        return true;
    }
    
    try {
        // Create connection
        websocketpp::lib::error_code ec;
        WebSocketClient::connection_ptr con = ws_client_.get_connection(
            config_.url, ec
        );
        
        if (ec) {
            cerr << "[WebSocket] Connection creation failed: " << ec.message() << endl;
            if (error_callback_) {
                error_callback_("Connection creation failed: " + ec.message());
            }
            return false;
        }
        
        // Save connection handle
        connection_hdl_ = con->get_handle();
        
        // Connect
        ws_client_.connect(con);
        
        // Start event loop in separate thread
        event_thread_ = make_unique<thread>([this]() {
            this->RunEventLoop();
        });
        
        // Wait for connection (with timeout)
        int wait_count = 0;
        while (!is_connected_ && wait_count < 50) {  // 5 seconds timeout
            this_thread::sleep_for(chrono::milliseconds(100));
            wait_count++;
        }
        
        if (!is_connected_) {
            cerr << "[WebSocket] Connection timeout" << endl;
            if (error_callback_) {
                error_callback_("Connection timeout");
            }
            return false;
        }
        
        // Start ping thread
        ping_thread_ = make_unique<thread>([this]() {
            this->PingLoop();
        });
        
        cout << "[WebSocket] Connected successfully" << endl;
        return true;
        
    } catch (const exception& e) {
        cerr << "[WebSocket] Connection exception: " << e.what() << endl;
        if (error_callback_) {
            error_callback_(string("Connection exception: ") + e.what());
        }
        return false;
    }
}

void OKXWebSocket::Disconnect() {
    {
        lock_guard<mutex> lock(mutex_);
        should_reconnect_ = false;
        is_connected_ = false;
    }
    
    // Stop ping thread
    if (ping_thread_ && ping_thread_->joinable()) {
        ping_thread_->join();
    }
    
    // Close connection
    try {
        websocketpp::lib::error_code ec;
        ws_client_.close(connection_hdl_, 
                        websocketpp::close::status::normal, 
                        "Disconnect requested", 
                        ec);
        if (ec) {
            cerr << "[WebSocket] Close failed: " << ec.message() << endl;
        }
    } catch (const exception& e) {
        cerr << "[WebSocket] Disconnect exception: " << e.what() << endl;
    }
    
    // Stop event loop
    StopEventLoop();
    
    // Wait for event thread
    if (event_thread_ && event_thread_->joinable()) {
        event_thread_->join();
    }
    
    cout << "[WebSocket] Disconnected" << endl;
}

bool OKXWebSocket::IsConnected() const {
    lock_guard<mutex> lock(mutex_);
    return is_connected_;
}

// ==================== Event Handlers ====================

void OKXWebSocket::OnOpen(websocketpp::connection_hdl hdl) {
    lock_guard<mutex> lock(mutex_);
    is_connected_ = true;
    connection_hdl_ = hdl;
    
    cout << "[WebSocket] Connection opened" << endl;
    
    // Update statistics
    {
        lock_guard<mutex> stats_lock(stats_mutex_);
        stats_.is_connected = true;
        if (stats_.reconnection_count > 0) {
            cout << "[WebSocket] Reconnected (attempt " 
                 << stats_.reconnection_count << ")" << endl;
        }
    }
}

void OKXWebSocket::OnClose(websocketpp::connection_hdl hdl) {
    {
        lock_guard<mutex> lock(mutex_);
        is_connected_ = false;
    }
    
    cout << "[WebSocket] Connection closed" << endl;
    
    // Update statistics
    {
        lock_guard<mutex> stats_lock(stats_mutex_);
        stats_.is_connected = false;
    }
    
    // Attempt reconnection if enabled
    if (config_.auto_reconnect && should_reconnect_) {
        cout << "[WebSocket] Attempting to reconnect..." << endl;
        reconnect_thread_ = make_unique<thread>([this]() {
            this->ReconnectionLoop();
        });
    }
}

void OKXWebSocket::OnFail(websocketpp::connection_hdl hdl) {
    {
        lock_guard<mutex> lock(mutex_);
        is_connected_ = false;
    }
    
    auto con = ws_client_.get_con_from_hdl(hdl);
    cerr << "[WebSocket] Connection failed: " 
         << con->get_ec().message() << endl;
    
    if (error_callback_) {
        error_callback_("Connection failed: " + con->get_ec().message());
    }
    
    // Update statistics
    {
        lock_guard<mutex> stats_lock(stats_mutex_);
        stats_.is_connected = false;
    }
    
    // Attempt reconnection if enabled
    if (config_.auto_reconnect && should_reconnect_) {
        cout << "[WebSocket] Attempting to reconnect after failure..." << endl;
        reconnect_thread_ = make_unique<thread>([this]() {
            this->ReconnectionLoop();
        });
    }
}

void OKXWebSocket::OnMessage(websocketpp::connection_hdl hdl, 
                              WebSocketClient::message_ptr msg) {
    // Update statistics
    {
        lock_guard<mutex> stats_lock(stats_mutex_);
        stats_.total_messages_received++;
        stats_.last_message_time = chrono::steady_clock::now();
    }
    
    // Process message
    try {
        const string& payload = msg->get_payload();
        
        // Debug output (optional)
        // cout << "[WebSocket] Received: " << payload << endl;
        
        ProcessMessage(payload);
        
    } catch (const exception& e) {
        cerr << "[WebSocket] Message processing error: " << e.what() << endl;
        if (error_callback_) {
            error_callback_(string("Message processing error: ") + e.what());
        }
    }
}

context_ptr OKXWebSocket::OnTLSInit(websocketpp::connection_hdl hdl) {
    context_ptr ctx = websocketpp::lib::make_shared<asio::ssl::context>(
        asio::ssl::context::tlsv12
    );
    
    try {
        ctx->set_options(
            asio::ssl::context::default_workarounds |
            asio::ssl::context::no_sslv2 |
            asio::ssl::context::no_sslv3 |
            asio::ssl::context::single_dh_use
        );
        
        ctx->set_verify_mode(asio::ssl::verify_none);
        
    } catch (const exception& e) {
        cerr << "[WebSocket] TLS init error: " << e.what() << endl;
    }
    
    return ctx;
}

// ==================== Message Processing ====================

void OKXWebSocket::ProcessMessage(const string& message) {
    try {
        json j = json::parse(message);
        
        // Check if it's an event message
        if (j.contains("event")) {
            string event = j["event"];
            
            if (event == "subscribe") {
                // Subscription confirmation
                if (j.contains("arg") && j["arg"].contains("channel")) {
                    string channel = j["arg"]["channel"];
                    cout << "[WebSocket] Subscribed to: " << channel << endl;
                }
            } else if (event == "unsubscribe") {
                // Unsubscription confirmation
                if (j.contains("arg") && j["arg"].contains("channel")) {
                    string channel = j["arg"]["channel"];
                    cout << "[WebSocket] Unsubscribed from: " << channel << endl;
                }
            } else if (event == "login") {
                // Login result
                if (j.contains("code")) {
                    string code = j["code"];
                    if (code == "0") {
                        cout << "[WebSocket] Login successful" << endl;
                    } else {
                        cerr << "[WebSocket] Login failed: " << j.dump() << endl;
                        if (error_callback_) {
                            error_callback_("Login failed: " + j.dump());
                        }
                    }
                }
            } else if (event == "error") {
                // Error message
                cerr << "[WebSocket] Error: " << j.dump() << endl;
                if (error_callback_) {
                    error_callback_("WebSocket error: " + j.dump());
                }
            }
            return;
        }
        
        // Check if it's a data message
        if (!j.contains("arg") || !j.contains("data")) {
            // Unknown message format, skip
            return;
        }
        
        json arg = j["arg"];
        if (!arg.contains("channel")) {
            return;
        }
        
        string channel = arg["channel"];
        
        // Route to appropriate handler
        if (channel == "tickers") {
            ProcessTickerMessage(j["data"]);
        } else if (channel == "books" || channel == "books5" || 
                   channel == "books-l2-tbt" || channel == "bbo-tbt") {
            ProcessDepthMessage(j["data"]);
        } else if (channel == "orders") {
            ProcessOrderMessage(j["data"]);
        } else if (channel == "positions") {
            ProcessPositionMessage(j["data"]);
        } else if (channel == "account") {
            ProcessAccountMessage(j["data"]);
        }
        
    } catch (const json::parse_error& e) {
        cerr << "[WebSocket] JSON parse error: " << e.what() << endl;
        if (error_callback_) {
            error_callback_(string("JSON parse error: ") + e.what());
        }
    } catch (const exception& e) {
        cerr << "[WebSocket] Message processing error: " << e.what() << endl;
        if (error_callback_) {
            error_callback_(string("Message processing error: ") + e.what());
        }
    }
}

void OKXWebSocket::ProcessTickerMessage(const json& data) {
    // Data is an array
    if (!data.is_array() || data.empty()) {
        return;
    }
    
    for (const auto& item : data) {
        try {
            // Parse ticker data
            Tick tick;
            tick.inst_id = item.value("instId", "");
            tick.last_price = stod(item.value("last", "0"));
            tick.bid_price = stod(item.value("bidPx", "0"));
            tick.ask_price = stod(item.value("askPx", "0"));
            tick.bid_size = stod(item.value("bidSz", "0"));
            tick.ask_size = stod(item.value("askSz", "0"));
            tick.open_24h = stod(item.value("open24h", "0"));
            tick.high_24h = stod(item.value("high24h", "0"));
            tick.low_24h = stod(item.value("low24h", "0"));
            tick.volume_24h = stod(item.value("vol24h", "0"));
            tick.volume_currency_24h = stod(item.value("volCcy24h", "0"));
            
            // Timestamp
            if (item.contains("ts")) {
                tick.timestamp = stoull(item["ts"].get<string>());
            }
            
            // Call callback if registered
            lock_guard<mutex> lock(mutex_);
            auto it = ticker_callbacks_.find(tick.inst_id);
            if (it != ticker_callbacks_.end() && it->second) {
                it->second(tick);
            }
            
        } catch (const exception& e) {
            cerr << "[WebSocket] Ticker parsing error: " << e.what() << endl;
        }
    }
}

void OKXWebSocket::ProcessDepthMessage(const json& data) {
    // Data is an array
    if (!data.is_array() || data.empty()) {
        return;
    }
    
    for (const auto& item : data) {
        try {
            // Parse depth data
            Depth depth;
            depth.inst_id = item.value("instId", "");
            
            // Parse bids
            if (item.contains("bids") && item["bids"].is_array()) {
                for (const auto& bid : item["bids"]) {
                    if (bid.is_array() && bid.size() >= 2) {
                        PriceLevel level;
                        level.price = stod(bid[0].get<string>());
                        level.size = stod(bid[1].get<string>());
                        depth.bids.push_back(level);
                    }
                }
            }
            
            // Parse asks
            if (item.contains("asks") && item["asks"].is_array()) {
                for (const auto& ask : item["asks"]) {
                    if (ask.is_array() && ask.size() >= 2) {
                        PriceLevel level;
                        level.price = stod(ask[0].get<string>());
                        level.size = stod(ask[1].get<string>());
                        depth.asks.push_back(level);
                    }
                }
            }
            
            // Timestamp
            if (item.contains("ts")) {
                depth.timestamp = stoull(item["ts"].get<string>());
            }
            
            // Call callback if registered
            lock_guard<mutex> lock(mutex_);
            auto it = depth_callbacks_.find(depth.inst_id);
            if (it != depth_callbacks_.end() && it->second) {
                it->second(depth);
            }
            
        } catch (const exception& e) {
            cerr << "[WebSocket] Depth parsing error: " << e.what() << endl;
        }
    }
}

void OKXWebSocket::ProcessOrderMessage(const json& data) {
    // TODO: 实现订单消息处理
    // 解析订单数据并调用回调
}

void OKXWebSocket::ProcessPositionMessage(const json& data) {
    // TODO: 实现持仓消息处理
    // 解析持仓数据并调用回调
}

void OKXWebSocket::ProcessAccountMessage(const json& data) {
    // TODO: 实现账户消息处理
    // 解析账户数据并调用回调
}

// ==================== Helper Functions ====================

void OKXWebSocket::RunEventLoop() {
    try {
        ws_client_.run();
    } catch (const exception& e) {
        cerr << "[WebSocket] Event loop exception: " << e.what() << endl;
    }
}

void OKXWebSocket::StopEventLoop() {
    try {
        ws_client_.stop();
    } catch (const exception& e) {
        cerr << "[WebSocket] Stop exception: " << e.what() << endl;
    }
}

// ==================== Statistics ====================

OKXWebSocket::Statistics OKXWebSocket::GetStatistics() const {
    lock_guard<mutex> lock(stats_mutex_);
    return stats_;
}

void OKXWebSocket::SetErrorCallback(ErrorCallback callback) {
    lock_guard<mutex> lock(mutex_);
    error_callback_ = callback;
}

// ==================== 文件未完成提示 ====================
// 
// 此文件是WebSocket实现的第1部分，已完成：
// ✅ 构造函数和析构函数
// ✅ 初始化和连接管理
// ✅ 事件处理器（OnOpen, OnClose, OnFail, OnMessage, OnTLSInit）
// ✅ 消息处理框架（ProcessMessage）
// ✅ Ticker和Depth消息解析
// ✅ 基础统计功能
//
// 还需要在第2部分完成：
// ⏳ 订阅管理（SubscribeTicker, SubscribeDepth等）
// ⏳ 私有频道认证（Authenticate, GenerateAuthSignature）
// ⏳ 重连机制（ReconnectionLoop, AttemptReconnect）
// ⏳ 心跳机制（PingLoop, SendPing）
// ⏳ Order/Position/Account消息处理
//
// 继续开发提示：
// 1. 下一步实现订阅管理功能（见下一个文件）
// 2. 参考OKX WebSocket文档：https://www.okx.com/docs-v5/en/#overview-websocket
// 3. 测试时先测试公共频道（不需要认证）
//
// ==================== 文件结束 ====================
