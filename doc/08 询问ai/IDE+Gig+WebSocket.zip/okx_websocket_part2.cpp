/**
 * @file okx_websocket_part2.cpp
 * @brief OKX WebSocket Client Implementation - Part 2
 * @author AI Assistant
 * @date 2025-11-05
 * 
 * 此文件是WebSocket实现的第2部分，包含：
 * - 订阅管理（公共和私有频道）
 * - 私有频道认证
 * - 自动重连机制
 * - 心跳维护
 * 
 * 注意：此文件需要与part1合并成完整的okx_websocket.cpp
 */

// ==================== Public Channel Subscriptions ====================

bool OKXWebSocket::SubscribeTicker(const string& inst_id, TickCallback callback) {
    {
        lock_guard<mutex> lock(mutex_);
        ticker_callbacks_[inst_id] = callback;
    }
    
    return SendSubscription("tickers", inst_id);
}

bool OKXWebSocket::SubscribeDepth(const string& inst_id, 
                                  DepthCallback callback,
                                  const string& depth_type) {
    {
        lock_guard<mutex> lock(mutex_);
        depth_callbacks_[inst_id] = callback;
    }
    
    return SendSubscription(depth_type, inst_id);
}

bool OKXWebSocket::UnsubscribeTicker(const string& inst_id) {
    {
        lock_guard<mutex> lock(mutex_);
        ticker_callbacks_.erase(inst_id);
    }
    
    return SendUnsubscription("tickers", inst_id);
}

bool OKXWebSocket::UnsubscribeDepth(const string& inst_id) {
    {
        lock_guard<mutex> lock(mutex_);
        depth_callbacks_.erase(inst_id);
    }
    
    return SendUnsubscription("books5", inst_id);
}

// ==================== Private Channel Subscriptions ====================

bool OKXWebSocket::SubscribeOrders(const string& inst_id, OrderCallback callback) {
    // Private channels require authentication first
    if (!Authenticate()) {
        cerr << "[WebSocket] Authentication failed, cannot subscribe to orders" << endl;
        return false;
    }
    
    {
        lock_guard<mutex> lock(mutex_);
        order_callbacks_[inst_id] = callback;
    }
    
    // Subscribe to orders channel
    json subscribe_msg = {
        {"op", "subscribe"},
        {"args", json::array()}
    };
    
    json arg;
    arg["channel"] = "orders";
    arg["instType"] = "SWAP";  // 合约类型
    
    if (!inst_id.empty()) {
        arg["instId"] = inst_id;
    }
    
    subscribe_msg["args"].push_back(arg);
    
    return SendMessage(subscribe_msg.dump());
}

bool OKXWebSocket::SubscribePositions(const string& inst_id, PositionCallback callback) {
    // Private channels require authentication first
    if (!Authenticate()) {
        cerr << "[WebSocket] Authentication failed, cannot subscribe to positions" << endl;
        return false;
    }
    
    {
        lock_guard<mutex> lock(mutex_);
        position_callbacks_[inst_id] = callback;
    }
    
    // Subscribe to positions channel
    json subscribe_msg = {
        {"op", "subscribe"},
        {"args", json::array()}
    };
    
    json arg;
    arg["channel"] = "positions";
    arg["instType"] = "SWAP";
    
    if (!inst_id.empty()) {
        arg["instId"] = inst_id;
    }
    
    subscribe_msg["args"].push_back(arg);
    
    return SendMessage(subscribe_msg.dump());
}

bool OKXWebSocket::SubscribeAccount(AccountCallback callback) {
    // Private channels require authentication first
    if (!Authenticate()) {
        cerr << "[WebSocket] Authentication failed, cannot subscribe to account" << endl;
        return false;
    }
    
    {
        lock_guard<mutex> lock(mutex_);
        account_callback_ = callback;
    }
    
    // Subscribe to account channel
    json subscribe_msg = {
        {"op", "subscribe"},
        {"args", json::array()}
    };
    
    json arg;
    arg["channel"] = "account";
    
    subscribe_msg["args"].push_back(arg);
    
    return SendMessage(subscribe_msg.dump());
}

bool OKXWebSocket::UnsubscribeOrders(const string& inst_id) {
    {
        lock_guard<mutex> lock(mutex_);
        order_callbacks_.erase(inst_id);
    }
    
    json unsubscribe_msg = {
        {"op", "unsubscribe"},
        {"args", json::array()}
    };
    
    json arg;
    arg["channel"] = "orders";
    arg["instType"] = "SWAP";
    if (!inst_id.empty()) {
        arg["instId"] = inst_id;
    }
    
    unsubscribe_msg["args"].push_back(arg);
    
    return SendMessage(unsubscribe_msg.dump());
}

bool OKXWebSocket::UnsubscribePositions(const string& inst_id) {
    {
        lock_guard<mutex> lock(mutex_);
        position_callbacks_.erase(inst_id);
    }
    
    json unsubscribe_msg = {
        {"op", "unsubscribe"},
        {"args", json::array()}
    };
    
    json arg;
    arg["channel"] = "positions";
    arg["instType"] = "SWAP";
    if (!inst_id.empty()) {
        arg["instId"] = inst_id;
    }
    
    unsubscribe_msg["args"].push_back(arg);
    
    return SendMessage(unsubscribe_msg.dump());
}

bool OKXWebSocket::UnsubscribeAccount() {
    {
        lock_guard<mutex> lock(mutex_);
        account_callback_ = nullptr;
    }
    
    json unsubscribe_msg = {
        {"op", "unsubscribe"},
        {"args", json::array()}
    };
    
    json arg;
    arg["channel"] = "account";
    
    unsubscribe_msg["args"].push_back(arg);
    
    return SendMessage(unsubscribe_msg.dump());
}

// ==================== Subscription Management ====================

bool OKXWebSocket::SendSubscription(const string& channel, const string& inst_id) {
    if (!is_connected_) {
        cerr << "[WebSocket] Not connected, cannot subscribe" << endl;
        return false;
    }
    
    // Create subscription message
    json subscribe_msg = {
        {"op", "subscribe"},
        {"args", json::array()}
    };
    
    json arg;
    arg["channel"] = channel;
    if (!inst_id.empty()) {
        arg["instId"] = inst_id;
    }
    
    subscribe_msg["args"].push_back(arg);
    
    // Send message
    bool result = SendMessage(subscribe_msg.dump());
    
    if (result) {
        lock_guard<mutex> lock(mutex_);
        string sub_key = channel + ":" + inst_id;
        active_subscriptions_.insert(sub_key);
        
        lock_guard<mutex> stats_lock(stats_mutex_);
        stats_.subscription_count = active_subscriptions_.size();
    }
    
    return result;
}

bool OKXWebSocket::SendUnsubscription(const string& channel, const string& inst_id) {
    if (!is_connected_) {
        cerr << "[WebSocket] Not connected, cannot unsubscribe" << endl;
        return false;
    }
    
    // Create unsubscription message
    json unsubscribe_msg = {
        {"op", "unsubscribe"},
        {"args", json::array()}
    };
    
    json arg;
    arg["channel"] = channel;
    if (!inst_id.empty()) {
        arg["instId"] = inst_id;
    }
    
    unsubscribe_msg["args"].push_back(arg);
    
    // Send message
    bool result = SendMessage(unsubscribe_msg.dump());
    
    if (result) {
        lock_guard<mutex> lock(mutex_);
        string sub_key = channel + ":" + inst_id;
        active_subscriptions_.erase(sub_key);
        
        lock_guard<mutex> stats_lock(stats_mutex_);
        stats_.subscription_count = active_subscriptions_.size();
    }
    
    return result;
}

bool OKXWebSocket::SendMessage(const string& message) {
    try {
        lock_guard<mutex> lock(mutex_);
        
        if (!is_connected_) {
            cerr << "[WebSocket] Not connected" << endl;
            return false;
        }
        
        websocketpp::lib::error_code ec;
        ws_client_.send(connection_hdl_, message, 
                       websocketpp::frame::opcode::text, ec);
        
        if (ec) {
            cerr << "[WebSocket] Send failed: " << ec.message() << endl;
            return false;
        }
        
        // Update statistics
        {
            lock_guard<mutex> stats_lock(stats_mutex_);
            stats_.total_messages_sent++;
        }
        
        return true;
        
    } catch (const exception& e) {
        cerr << "[WebSocket] Send exception: " << e.what() << endl;
        return false;
    }
}

// ==================== Authentication ====================

bool OKXWebSocket::Authenticate() {
    if (!signer_) {
        cerr << "[WebSocket] No signer configured, cannot authenticate" << endl;
        return false;
    }
    
    try {
        // Generate timestamp
        string timestamp = signer_->GetTimestamp();
        
        // Generate signature
        string signature = GenerateAuthSignature(timestamp);
        
        // Create login message
        json login_msg = {
            {"op", "login"},
            {"args", json::array()}
        };
        
        json arg;
        arg["apiKey"] = config_.api_key;
        arg["passphrase"] = config_.passphrase;
        arg["timestamp"] = timestamp;
        arg["sign"] = signature;
        
        login_msg["args"].push_back(arg);
        
        // Send login message
        cout << "[WebSocket] Sending login request..." << endl;
        return SendMessage(login_msg.dump());
        
    } catch (const exception& e) {
        cerr << "[WebSocket] Authentication exception: " << e.what() << endl;
        return false;
    }
}

string OKXWebSocket::GenerateAuthSignature(const string& timestamp) {
    // Sign string format: timestamp + "GET" + "/users/self/verify"
    string sign_str = timestamp + "GET" + "/users/self/verify";
    
    // Use signer to generate signature
    return signer_->GenerateSignature(timestamp, "GET", "/users/self/verify", "");
}

// ==================== Reconnection Logic ====================

void OKXWebSocket::ReconnectionLoop() {
    int attempt = 0;
    int delay = config_.reconnect_delay_seconds;
    
    while (should_reconnect_ && !is_connected_ && 
           attempt < config_.max_reconnect_attempts) {
        
        attempt++;
        
        cout << "[WebSocket] Reconnection attempt " << attempt 
             << "/" << config_.max_reconnect_attempts << endl;
        
        // Update statistics
        {
            lock_guard<mutex> stats_lock(stats_mutex_);
            stats_.reconnection_count++;
        }
        
        // Wait before attempting
        this_thread::sleep_for(chrono::seconds(delay));
        
        // Attempt to reconnect
        if (AttemptReconnect()) {
            cout << "[WebSocket] Reconnection successful!" << endl;
            
            // Resubscribe to all channels
            lock_guard<mutex> lock(mutex_);
            for (const auto& sub_key : active_subscriptions_) {
                // Parse subscription key (format: "channel:inst_id")
                size_t colon_pos = sub_key.find(':');
                if (colon_pos != string::npos) {
                    string channel = sub_key.substr(0, colon_pos);
                    string inst_id = sub_key.substr(colon_pos + 1);
                    
                    cout << "[WebSocket] Resubscribing to " << channel 
                         << " for " << inst_id << endl;
                    
                    SendSubscription(channel, inst_id);
                }
            }
            
            return;
        }
        
        // Exponential backoff (double delay, max 30 seconds)
        delay = min(delay * 2, 30);
    }
    
    if (!is_connected_) {
        cerr << "[WebSocket] Failed to reconnect after " 
             << config_.max_reconnect_attempts << " attempts" << endl;
        
        if (error_callback_) {
            error_callback_("Reconnection failed after " + 
                          to_string(config_.max_reconnect_attempts) + " attempts");
        }
    }
}

bool OKXWebSocket::AttemptReconnect() {
    try {
        // Close old connection if any
        try {
            websocketpp::lib::error_code ec;
            ws_client_.close(connection_hdl_, 
                           websocketpp::close::status::normal, 
                           "Reconnecting", ec);
        } catch (...) {
            // Ignore errors during close
        }
        
        // Wait a bit
        this_thread::sleep_for(chrono::milliseconds(500));
        
        // Create new connection
        websocketpp::lib::error_code ec;
        WebSocketClient::connection_ptr con = ws_client_.get_connection(
            config_.url, ec
        );
        
        if (ec) {
            cerr << "[WebSocket] Reconnection failed: " << ec.message() << endl;
            return false;
        }
        
        // Save connection handle
        connection_hdl_ = con->get_handle();
        
        // Connect
        ws_client_.connect(con);
        
        // Wait for connection
        int wait_count = 0;
        while (!is_connected_ && wait_count < 50) {  // 5 seconds timeout
            this_thread::sleep_for(chrono::milliseconds(100));
            wait_count++;
        }
        
        return is_connected_;
        
    } catch (const exception& e) {
        cerr << "[WebSocket] Reconnection exception: " << e.what() << endl;
        return false;
    }
}

// ==================== Ping/Pong Mechanism ====================

void OKXWebSocket::PingLoop() {
    while (should_reconnect_) {
        // Wait for ping interval
        this_thread::sleep_for(
            chrono::seconds(config_.ping_interval_seconds)
        );
        
        // Check if still connected
        if (!is_connected_) {
            continue;
        }
        
        // Send ping
        SendPing();
        
        // Check last message time
        {
            lock_guard<mutex> stats_lock(stats_mutex_);
            auto now = chrono::steady_clock::now();
            auto elapsed = chrono::duration_cast<chrono::seconds>(
                now - stats_.last_message_time
            ).count();
            
            // If no message received for 60 seconds, assume connection is dead
            if (elapsed > 60 && is_connected_) {
                cerr << "[WebSocket] No message received for " << elapsed 
                     << " seconds, assuming connection is dead" << endl;
                
                // Trigger reconnection
                OnClose(connection_hdl_);
            }
        }
    }
}

void OKXWebSocket::SendPing() {
    try {
        // OKX WebSocket uses text "ping" message
        json ping_msg = "ping";
        
        bool result = SendMessage(ping_msg.dump());
        
        if (result) {
            // cout << "[WebSocket] Ping sent" << endl;
        } else {
            cerr << "[WebSocket] Ping failed" << endl;
        }
        
    } catch (const exception& e) {
        cerr << "[WebSocket] Ping exception: " << e.what() << endl;
    }
}

// ==================== Order/Position/Account Message Processing ====================

void OKXWebSocket::ProcessOrderMessage(const json& data) {
    // Data is an array
    if (!data.is_array() || data.empty()) {
        return;
    }
    
    for (const auto& item : data) {
        try {
            // Parse order data
            Order order;
            order.inst_id = item.value("instId", "");
            order.order_id = item.value("ordId", "");
            order.client_order_id = item.value("clOrdId", "");
            order.side = item.value("side", "");
            order.position_side = item.value("posSide", "");
            order.order_type = item.value("ordType", "");
            order.trade_mode = item.value("tdMode", "");
            
            // Prices and sizes
            order.price = stod(item.value("px", "0"));
            order.size = stod(item.value("sz", "0"));
            order.filled_size = stod(item.value("accFillSz", "0"));
            order.avg_fill_price = stod(item.value("avgPx", "0"));
            
            // State and fees
            order.state = item.value("state", "");
            order.fee = stod(item.value("fee", "0"));
            order.pnl = stod(item.value("pnl", "0"));
            
            // Timestamps
            if (item.contains("cTime")) {
                order.create_time = stoull(item["cTime"].get<string>());
            }
            if (item.contains("uTime")) {
                order.update_time = stoull(item["uTime"].get<string>());
            }
            
            // Call callback if registered
            lock_guard<mutex> lock(mutex_);
            auto it = order_callbacks_.find(order.inst_id);
            if (it != order_callbacks_.end() && it->second) {
                it->second(order);
            }
            
            // Also call callback for empty inst_id (all instruments)
            auto it_all = order_callbacks_.find("");
            if (it_all != order_callbacks_.end() && it_all->second) {
                it_all->second(order);
            }
            
        } catch (const exception& e) {
            cerr << "[WebSocket] Order parsing error: " << e.what() << endl;
        }
    }
}

void OKXWebSocket::ProcessPositionMessage(const json& data) {
    // Data is an array
    if (!data.is_array() || data.empty()) {
        return;
    }
    
    for (const auto& item : data) {
        try {
            // Parse position data
            Position position;
            position.inst_id = item.value("instId", "");
            position.position_side = item.value("posSide", "");
            position.position = stod(item.value("pos", "0"));
            position.available_position = stod(item.value("availPos", "0"));
            position.avg_price = stod(item.value("avgPx", "0"));
            
            // PnL
            position.unrealized_pnl = stod(item.value("upl", "0"));
            position.unrealized_pnl_ratio = stod(item.value("uplRatio", "0"));
            
            // Margin
            position.margin = stod(item.value("margin", "0"));
            position.margin_ratio = stod(item.value("mgnRatio", "0"));
            
            // Leverage
            position.leverage = stod(item.value("lever", "0"));
            
            // Timestamps
            if (item.contains("uTime")) {
                position.update_time = stoull(item["uTime"].get<string>());
            }
            
            // Call callback if registered
            lock_guard<mutex> lock(mutex_);
            auto it = position_callbacks_.find(position.inst_id);
            if (it != position_callbacks_.end() && it->second) {
                it->second(position);
            }
            
            // Also call callback for empty inst_id (all instruments)
            auto it_all = position_callbacks_.find("");
            if (it_all != position_callbacks_.end() && it_all->second) {
                it_all->second(position);
            }
            
        } catch (const exception& e) {
            cerr << "[WebSocket] Position parsing error: " << e.what() << endl;
        }
    }
}

void OKXWebSocket::ProcessAccountMessage(const json& data) {
    // Data is an array
    if (!data.is_array() || data.empty()) {
        return;
    }
    
    for (const auto& item : data) {
        try {
            // Parse account data
            Account account;
            account.total_equity = stod(item.value("totalEq", "0"));
            account.isolated_equity = stod(item.value("isoEq", "0"));
            account.margin_ratio = stod(item.value("mgnRatio", "0"));
            account.adj_equity = stod(item.value("adjEq", "0"));
            
            // Timestamps
            if (item.contains("uTime")) {
                account.update_time = stoull(item["uTime"].get<string>());
            }
            
            // Call callback if registered
            lock_guard<mutex> lock(mutex_);
            if (account_callback_) {
                account_callback_(account);
            }
            
        } catch (const exception& e) {
            cerr << "[WebSocket] Account parsing error: " << e.what() << endl;
        }
    }
}

// ==================== 文件未完成提示 ====================
// 
// 此文件是WebSocket实现的第2部分，已完成：
// ✅ 公共频道订阅（Ticker, Depth）
// ✅ 私有频道订阅（Orders, Positions, Account）
// ✅ 订阅管理（Subscribe, Unsubscribe）
// ✅ 私有频道认证（Authenticate, GenerateAuthSignature）
// ✅ 自动重连机制（ReconnectionLoop, AttemptReconnect）
// ✅ 心跳维护（PingLoop, SendPing）
// ✅ Order/Position/Account消息处理
//
// 完整的WebSocket实现步骤：
// 1. 将part1.cpp和part2.cpp合并为完整的okx_websocket.cpp
// 2. 编译项目：
//    - 确保安装WebSocket++库
//    - 更新CMakeLists.txt添加WebSocket++支持
// 3. 创建测试程序test_websocket.cpp
// 4. 测试公共频道（Ticker, Depth）
// 5. 测试私有频道（需要API密钥）
//
// 下一步：
// - 创建完整的okx_websocket.cpp（合并part1和part2）
// - 创建测试程序
// - 更新CMakeLists.txt
//
// ==================== 文件结束 ====================
