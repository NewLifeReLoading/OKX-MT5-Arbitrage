/**
 * @file test_websocket.cpp
 * @brief OKX WebSocket Client Test Program
 * @author AI Assistant
 * @date 2025-11-05
 * 
 * 测试WebSocket功能：
 * - 公共频道订阅（Ticker, Depth）
 * - 私有频道订阅（Orders, Positions, Account）
 * - 自动重连
 * - 心跳维护
 */

#include "okx_websocket.h"
#include "config.h"
#include <iostream>
#include <thread>
#include <chrono>
#include <iomanip>
#include <csignal>
#include <atomic>

using namespace std;

// Global flag for graceful shutdown
atomic<bool> g_running(true);

void SignalHandler(int signal) {
    cout << "\n[Test] Received signal " << signal << ", shutting down..." << endl;
    g_running = false;
}

// ==================== Utility Functions ====================

string FormatTimestamp(uint64_t ts_ms) {
    time_t ts_sec = ts_ms / 1000;
    struct tm* tm_info = localtime(&ts_sec);
    
    char buffer[80];
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", tm_info);
    
    return string(buffer) + "." + to_string(ts_ms % 1000);
}

void PrintSeparator(const string& title = "") {
    cout << "\n";
    cout << "==================================================\n";
    if (!title.empty()) {
        cout << "  " << title << "\n";
        cout << "==================================================\n";
    }
}

// ==================== Test 1: Public Channels ====================

void TestPublicChannels() {
    PrintSeparator("TEST 1: Public Channels (Ticker & Depth)");
    
    // Create WebSocket client
    OKXWebSocket ws;
    
    // Configure
    OKXWebSocket::WSConfig config;
    config.url = "wss://wspap.okx.com:8443/ws/v5/public?brokerId=9999";  // 模拟盘
    config.auto_reconnect = true;
    config.reconnect_delay_seconds = 5;
    config.ping_interval_seconds = 20;
    
    // Initialize
    if (!ws.Initialize(config)) {
        cerr << "[Test] Failed to initialize WebSocket" << endl;
        return;
    }
    
    cout << "[Test] WebSocket initialized" << endl;
    
    // Connect
    if (!ws.Connect()) {
        cerr << "[Test] Failed to connect to WebSocket" << endl;
        return;
    }
    
    cout << "[Test] Connected to WebSocket" << endl;
    
    // Set error callback
    ws.SetErrorCallback([](const string& error) {
        cerr << "[Test] Error: " << error << endl;
    });
    
    // Subscribe to Ticker
    cout << "[Test] Subscribing to ticker for XAUT-USDT-SWAP..." << endl;
    bool ticker_subscribed = ws.SubscribeTicker("XAUT-USDT-SWAP", 
        [](const Tick& tick) {
            cout << "\n[Ticker Update]" << endl;
            cout << "  Instrument: " << tick.inst_id << endl;
            cout << "  Last:       " << fixed << setprecision(2) << tick.last_price << endl;
            cout << "  Bid:        " << tick.bid_price << " x " << tick.bid_size << endl;
            cout << "  Ask:        " << tick.ask_price << " x " << tick.ask_size << endl;
            cout << "  24h High:   " << tick.high_24h << endl;
            cout << "  24h Low:    " << tick.low_24h << endl;
            cout << "  24h Volume: " << tick.volume_24h << endl;
            cout << "  Time:       " << FormatTimestamp(tick.timestamp) << endl;
        }
    );
    
    if (!ticker_subscribed) {
        cerr << "[Test] Failed to subscribe to ticker" << endl;
    }
    
    // Subscribe to Depth
    cout << "[Test] Subscribing to depth (top 5) for XAUT-USDT-SWAP..." << endl;
    bool depth_subscribed = ws.SubscribeDepth("XAUT-USDT-SWAP", 
        [](const Depth& depth) {
            cout << "\n[Depth Update]" << endl;
            cout << "  Instrument: " << depth.inst_id << endl;
            
            // Print asks (sell orders)
            cout << "  Asks (Sellers):" << endl;
            for (int i = min(5, (int)depth.asks.size()) - 1; i >= 0; i--) {
                cout << "    " << fixed << setprecision(2) 
                     << depth.asks[i].price << " x " 
                     << depth.asks[i].size << endl;
            }
            
            cout << "  -------- Spread --------" << endl;
            if (!depth.bids.empty() && !depth.asks.empty()) {
                double spread = depth.asks[0].price - depth.bids[0].price;
                cout << "  Spread: " << fixed << setprecision(2) << spread << endl;
            }
            
            // Print bids (buy orders)
            cout << "  Bids (Buyers):" << endl;
            for (int i = 0; i < min(5, (int)depth.bids.size()); i++) {
                cout << "    " << fixed << setprecision(2) 
                     << depth.bids[i].price << " x " 
                     << depth.bids[i].size << endl;
            }
            
            cout << "  Time: " << FormatTimestamp(depth.timestamp) << endl;
        },
        "books5"  // Top 5 levels
    );
    
    if (!depth_subscribed) {
        cerr << "[Test] Failed to subscribe to depth" << endl;
    }
    
    // Run for 30 seconds
    cout << "\n[Test] Listening for updates for 30 seconds..." << endl;
    cout << "[Test] Press Ctrl+C to stop early" << endl;
    
    for (int i = 0; i < 30 && g_running; i++) {
        this_thread::sleep_for(chrono::seconds(1));
        
        // Print statistics every 5 seconds
        if ((i + 1) % 5 == 0) {
            auto stats = ws.GetStatistics();
            cout << "\n[Statistics]" << endl;
            cout << "  Connected:        " << (stats.is_connected ? "Yes" : "No") << endl;
            cout << "  Messages Sent:    " << stats.total_messages_sent << endl;
            cout << "  Messages Received: " << stats.total_messages_received << endl;
            cout << "  Subscriptions:    " << stats.subscription_count << endl;
            cout << "  Reconnections:    " << stats.reconnection_count << endl;
        }
    }
    
    // Unsubscribe
    cout << "\n[Test] Unsubscribing..." << endl;
    ws.UnsubscribeTicker("XAUT-USDT-SWAP");
    ws.UnsubscribeDepth("XAUT-USDT-SWAP");
    
    // Disconnect
    cout << "[Test] Disconnecting..." << endl;
    ws.Disconnect();
    
    cout << "[Test] Test completed" << endl;
}

// ==================== Test 2: Private Channels ====================

void TestPrivateChannels(const string& config_file) {
    PrintSeparator("TEST 2: Private Channels (Orders, Positions, Account)");
    
    // Load configuration
    Config config;
    if (!config.Load(config_file)) {
        cerr << "[Test] Failed to load configuration" << endl;
        return;
    }
    
    auto okx_config = config.GetOKXConfig();
    
    // Create WebSocket client
    OKXWebSocket ws;
    
    // Configure
    OKXWebSocket::WSConfig ws_config;
    ws_config.private_url = okx_config.ws_private;
    ws_config.api_key = okx_config.api_key;
    ws_config.secret_key = okx_config.secret_key;
    ws_config.passphrase = okx_config.passphrase;
    ws_config.auto_reconnect = true;
    
    // Initialize
    if (!ws.Initialize(ws_config)) {
        cerr << "[Test] Failed to initialize WebSocket" << endl;
        return;
    }
    
    // Connect (to private channel)
    // Note: Need to modify Connect() to support private URL
    // For now, this is a placeholder
    
    cout << "[Test] Private channel test is not yet fully implemented" << endl;
    cout << "[Test] This requires connecting to private WebSocket endpoint" << endl;
    cout << "[Test] and handling authentication" << endl;
    
    // TODO: Complete private channel testing when implementation is ready
}

// ==================== Test 3: Reconnection ====================

void TestReconnection() {
    PrintSeparator("TEST 3: Auto-Reconnection");
    
    // This test would require simulating a network failure
    // or manually disconnecting the WebSocket
    
    cout << "[Test] Reconnection test requires manual intervention" << endl;
    cout << "[Test] To test:" << endl;
    cout << "  1. Run the test" << endl;
    cout << "  2. Disconnect network or kill the connection" << endl;
    cout << "  3. Observe automatic reconnection" << endl;
    cout << "  4. Verify subscriptions are restored" << endl;
}

// ==================== Main ====================

int main(int argc, char* argv[]) {
    // Setup signal handler
    signal(SIGINT, SignalHandler);
    signal(SIGTERM, SignalHandler);
    
    cout << "========================================" << endl;
    cout << "  OKX WebSocket Test Program" << endl;
    cout << "========================================" << endl;
    
    // Test selection
    cout << "\nSelect test:" << endl;
    cout << "  1. Public Channels (Ticker & Depth)" << endl;
    cout << "  2. Private Channels (Orders, Positions, Account)" << endl;
    cout << "  3. Auto-Reconnection Test" << endl;
    cout << "  0. Exit" << endl;
    cout << "\nEnter choice: ";
    
    int choice;
    cin >> choice;
    
    switch (choice) {
        case 1:
            TestPublicChannels();
            break;
            
        case 2:
            if (argc < 2) {
                cerr << "Usage: " << argv[0] << " <config_file>" << endl;
                cerr << "Example: " << argv[0] << " ../config/config.json" << endl;
                return 1;
            }
            TestPrivateChannels(argv[1]);
            break;
            
        case 3:
            TestReconnection();
            break;
            
        case 0:
            cout << "Exiting..." << endl;
            return 0;
            
        default:
            cerr << "Invalid choice" << endl;
            return 1;
    }
    
    return 0;
}

// ==================== 编译和运行说明 ====================
//
// 编译：
//   在CMakeLists.txt中添加：
//   ```cmake
//   # WebSocket test
//   add_executable(test_websocket tests/test_websocket.cpp)
//   target_link_libraries(test_websocket okx_api pthread)
//   ```
//
//   然后编译：
//   cd build
//   cmake ..
//   cmake --build .
//
// 运行：
//   # 测试公共频道
//   ./test_websocket
//   选择 1
//
//   # 测试私有频道（需要配置文件）
//   ./test_websocket ../config/config.json
//   选择 2
//
// 预期输出：
//   - 成功连接到WebSocket
//   - 接收到实时Ticker更新
//   - 接收到实时Depth更新
//   - 每5秒显示统计信息
//   - 30秒后自动断开
//
// ==================== 文件结束 ====================
